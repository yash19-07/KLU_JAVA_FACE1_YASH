// import java.util.*;
// public class Day11 {
//     public static void main(String[] args){
//         Scanner sc = new Scanner(System.in);
//         System.out.print("Enter the String: ");
//         String s=sc.nextLine();
//         String rev="";
//         int i;
//         for(i=s.length()-1;i>=0;i--)
//             rev=rev+s.charAt(i);
//         if(s.equals(rev))
//             System.out.println("String Pallindrome");
//         else 
//             System.out.println("Not a palindrome");
//     }
// }


// Output
// Enter the String: MOM
// String Pallindrome



//==========================================================================================


// write a java program to print the unique elements count in the given string

// import java.util.*;
// public class Day11 {
//     public static void main(String[] args){
//         Scanner sc = new Scanner(System.in);
//         System.out.print("Enter the String: ");
//         String s = sc.nextLine();
//         int freq[]=new int[256];
//         int i,count=0;
//         for(i=0;i<s.length();i++){
//             char ch=s.charAt(i);
//             freq[ch]++;
//         }
//         for(i=0;i<256;i++)
//         {
//             if(freq[i]==1){
//                 count++;
//             }
//         }
//         System.out.println("Unique element count : "+count);
//     }}


// Output
// Enter the String: BOTTLE
// Unique element count : 4


//==========================================================================================

// write a java program to print the duplicate elements count in the given string

// import java.util.*;
// public class Day11 {
//     public static void main(String[] args){
//         Scanner sc = new Scanner(System.in);
//         System.out.print("Enter the String: ");
//         String s = sc.nextLine();
//         int freq[]=new int[256];
//         int i,count=0;
//         for(i=0;i<s.length();i++){
//             char ch=s.charAt(i);
//             freq[ch]++;
//         }
//         for(i=0;i<256;i++)
//         {
//             if(freq[i]>1){
//                 System.out.println((char)(i));
//                 count++;
//             }
//         }
//         System.out.println("Unique element count : "+count);
//     }}


// Output
// Enter the String: BOTTLE
// Unique element count : 1


//==========================================================================================

//Bubble Sort

// import java.util.*;
// public class Day11{
//     public static void main(String[] args){
//         Scanner sc = new Scanner(System.in);
//         System.out.print("Enter the size of array: ");
//         int n=sc.nextInt();
//         int i,j;
//         int arr[]=new int[n];
//         System.out.print("Enter the elements of the array: ");
//         for(i=0;i<n;i++)
//             arr[i]=sc.nextInt();
//         for(i=0;i<n;i++){
//             for(j=0;j<n-1;j++){
//                 if(arr[j]>arr[j+1]){
//                     int temp = arr[j];
//                     arr[j] = arr[j+1];
//                     arr[j+1] = temp;
//                 }
//             }
//         }
//         for(i=0;i<n;i++)
//             System.out.print(arr[i]+ " ");

//     }
// }


// Output
// Enter the size of array: 5
// Enter the elements of the array: 7 4 9 2 5 
// 2 4 5 7 9 

//==========================================================================================


//Selection Sorting

// import java.util.*;
// public class Main{
//     public static void main(String[] args){
//         Scanner sc = new Scanner(System.in);
//         System.out.print("Enter the size of the array : ");
//         int n=sc.nextInt();
//         int arr[]=new int[n];
//         System.out.print("Enter the elements of the array: ");
//         int i,j;
//         for(i=0;i<n;i++)
//             arr[i]=sc.nextInt();
//         for(i=0;i<n;i++){
//             int minind=i;
//             for(j=i+1;j<n;j++){
//                 if(arr[j]<arr[minind]){
//                     minind=j;

//                 }
//             }
//             int temp=arr[i];
//             arr[i]=arr[minind];
//             arr[minind]=temp;

//         }
//         for(i=0;i<n;i++)
//             System.out.print(arr[i]+" ");
//     }

// }


// Output
// Enter the size of the array : 5
// Enter the elements of the array: 64 25 12 22 11
// 11 12 22 25 64 

//==========================================================================================


//Insertion Sorting

// import java.util.*;
// public class Day11{
//     public static void main(String[] args){
//         Scanner sc = new Scanner(System.in);
//         System.out.print("Enter the size of the array : ");
//         int n=sc.nextInt();
//         int arr[]=new int[n];
//         System.out.print("Enter the elements of the array: ");
//         int i,j;
//         for(i=0;i<n;i++)
//             arr[i]=sc.nextInt();
//         for(i=1;i<n;i++){
//             int key =arr[i];
//             j=i-1;
//             while(j>=0&&arr[j]>key){
//                 arr[j+1]=arr[j];
//                 j--;
//             }
//             arr[j+1]=key;

//         }
//         for(i=0;i<n;i++){
//             System.out.print(arr[i]+" ");
//         }
//     }
//         }


// Output
// Enter the size of the array : 5
// Enter the elements of the array: 12 11 13 5 6
// 5 6 11 12 13 


// can we create multiple main method in a single class 
// yes it is possible ,the main method which is containing string method is considered as main method 



// can we implement a program without a class
// yes it is possible in the current updation of java version 


